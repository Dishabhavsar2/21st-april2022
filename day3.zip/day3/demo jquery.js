<html>
<head>
    <title>demo jquery</title>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js" type="text/javascript"></script>
<body>
    <div id="MyDiv" style="height:300px;width:300px;background-color:Navy;"></div><hr />
    <button id="BtnHide">Hide</button>&nbsp;&nbsp;<button id="BtnShow">Show</button><hr />
    <button id="BtnToggle">Hide</button><hr/>
    <button id="BtnPlus" style="font-size:xx-large;"><b>+</b></button>&nbsp;&nbsp;<button id="BtnMinus" style="font-size:xx-large;"><b>-</b></button><hr />

</body>
</html>